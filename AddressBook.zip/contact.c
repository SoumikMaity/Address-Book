#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include <ctype.h>

void listContacts(AddressBook *addressBook) 
{
    if(addressBook->contactCount==0)
    {
        printf("No contact found");
        return;
    }
    printf("\n%-5s %-20s %-15s %-30s\n", "No", "Name", "Phone", "Email");
    printf("--------------------------------------------------------------\n");
    for (int i = 0; i < addressBook->contactCount; i++)
    {
        printf("%-5d %-20s %-15s %-30s\n", i + 1,
            addressBook->contacts[i].name,
            addressBook->contacts[i].phone,
            addressBook->contacts[i].email);
    }
    printf("Total contacts: %d\n",addressBook->contactCount);
}

void saveAndExit(AddressBook *addressBook) 
{
    saveContactsToFile(addressBook); // Save contacts to file
    exit(EXIT_SUCCESS); // Exit the program
}


void createContact(AddressBook *addressBook)
{
	if(addressBook->contactCount>=MAX_CONTACTS)
    {
        printf("Address Book is full!\n");
        return;
    }
    //---------------Name Validation--------------------//

    char name[50];
    int attempts=0,maxAttempts=3;

    while(attempts<maxAttempts)
    {
        int i,valid=1,len;
        attempts++;
        printf("Enter the name (Attempt %d of %d):",attempts,maxAttempts);
        scanf(" %49[^\n]",name);
        len=strlen(name);
        if(len<3)
        {
            printf("Invalid: Name must be atleast 2 characters long.\n");
            valid=0;
        }
        else if(!isupper(name[0]))
        {
            printf("Invalid: First letter must be uppercase.\n");
            valid=0;
        }
        else
        {
           for(i=0;name[i]!='\0';i++)
           {
               if(!isalpha(name[i])&&name[i]!=' ')
                {
                   printf("Invalid: Name can only contain alphabetic and spaces.\n");
                   valid=0;
                   break;
                }
                if(name[i]==' '&&name[i+1]==' ')
                {
                    printf("Invalid: Multiple spaces are not allowed.\n");
                    valid=0;
                    break;
                }
            }
        }
        if(valid)
        {
            printf("Valid name entered: %s\n",name);
            break;
        }
        if(attempts==maxAttempts)
        {
            printf("Too many invalid attempts.\n");
            return;
        } 
    }
    strcpy(addressBook->contacts[addressBook->contactCount].name,name);

    //---------------------Phone Number Validation------------------------//

    char number[20];
     attempts=0,maxAttempts=3;
    while(attempts<maxAttempts)
    {
        int i,duplicate=0;
        attempts++;
        printf("Enter the phone number (Attempt %d of %d):",attempts,maxAttempts);
        scanf(" %19[^\n]",number);
        if(strlen(number)!=10)
        {
            printf("Phone number must be exactly 10 digits\n");
            continue;
        }
        for(i=0;i<10;i++)
        {
            if(!isdigit(number[i]))
            {
                printf("Number must be contain only digits\n");
                break;
            }
        }
        if(i!=10)
        {
            continue;
        }
            //check duplicate----//
        for(i=0;i<addressBook->contactCount;i++)
        {
            if(strcmp(addressBook->contacts[i].phone,number)==0)
            {
                printf("The phone number already exists\n");
                duplicate=1;
                break;
            }
        }
        if(duplicate)
        {
            continue;        
        }
        printf("Phone number accepted: %s\n",number);
        break;
    }
    if(attempts==maxAttempts)
    {
        printf("Maximum attempts reached. Could not enter a valid phone number.\n");
        return;
    }
    strcpy(addressBook->contacts[addressBook->contactCount].phone,number);
   


  //-------------------Email Validation---------------------//
  char mail[50];
    int i; 
    attempts=0;maxAttempts=3;
    while(attempts<maxAttempts)
    {
        int count=0,valid=1;
        attempts++;
        printf("Enter the Email(Attempt %d of %d):",attempts,maxAttempts);
        scanf(" %[^\n]",mail);

        for(i=0;mail[i]!='\0';i++)
        {
            if(isupper(mail[i]))
            {
                printf("Error: Email must be lowercase\n");
                valid=0;
                break;
            }
        }
        if(!valid)continue;

         for(i=0;mail[i]!='\0';i++)
        {
            if(mail[i]=='@')
            {
                count++;
            }
        }
        if(count!=1)
        {
            printf("Error: Email must contain exactly one '@\n");
            continue;
        }

        int len=strlen(mail);
        if( len<5 || strcmp(&mail[len-4],".com")!=0)
        {
            printf("Error: Email must end with '.com'\n");
            continue;
        }

        valid=1;
        for(i=0;mail[i]!='\0';i++)
        {
            if(!(islower(mail[i])||isdigit(mail[i]) || mail[i]=='@' || mail[i] == '.' || mail[i]=='_' || mail[i]=='-'))
            {
                printf("Error: Invalid charcter '%c' Only letters,digits,@ . _ - allowed.\n",mail[i]);
                valid=0;
                break;
            }
        }
        if(!valid)continue;

       int duplicate=0;
       for (i = 0; i<addressBook->contactCount; i++)
       {
           if(strcmp(addressBook->contacts[i].email,mail)==0)
           {
             printf("This email already exits.\n");
             duplicate=1;
             break;
           }
        }
        if(duplicate)
        {
            continue;
        }
        break;
    }
    if(attempts==maxAttempts)
    {
        printf("Maximum attempts reached. Could not enter a valid email.\n");
        return;
    }
    strcpy(addressBook->contacts[addressBook->contactCount].email,mail);
    addressBook->contactCount++;
    printf("Contact added successfully!\n");    

}
void searchContact(AddressBook *addressBook) 
{
    if(addressBook->contactCount==0)
    {
        printf("\nNo contacts to search\n");
        return;
    }
    char search[50];
    int choice;
    int found=0;
    do
    {
        printf("\nSearch By:\n");
        printf("1.Name\n");
        printf("2.Phone number\n");
        printf("3.Email Id\n");
        printf("4.Back to main menu\n");
            
        printf("Enter the choice:");
        scanf("%d",&choice);
        switch(choice)
        {
            case 1:
            printf("Enter name to search: ");
            scanf(" %[^\n]",search);

            printf("\n%-5s %-20s %-15s %-30s\n","No","Name","Phone","Email");
            printf("-------------------------------------------------------------\n");

            for(int i=0;i<addressBook->contactCount;i++)
            {
                if(strcmp(addressBook->contacts[i].name,search)==0)
                {
                    printf("%-5d %-20s %-15s %-30s\n",i+1,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
                    found=1;
                } 
            }
            if(!found)
            {
                printf("No contacts found searching by this name:%s\n",search);
            }
                return;
             //---------------------search by phone------------------------------//
            case 2:
            printf("Enter phone number to search: ");
            scanf(" %[^\n]",search);

            printf("\n%-5s %-20s %-15s %-30s\n","No","Name","Phone","Email");
            printf("-----------------------------------------------------\n");

            for(int i=0;i<addressBook->contactCount;i++)
            {
                if(strcmp(addressBook->contacts[i].phone,search)==0)
                {   
                    printf("%-5d %-20s %-15s %-30s",i+1,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
                    found=1;
                } 
            }
            if(!found)
            {
                printf("No contacts found searching by this number:%s\n",search);
            }
            return;
//-------------------Search by email------------------//
            case 3:
            printf("Enter email to search: ");
            scanf(" %[^\n]",search);

            printf("\n%-5s %-20s %-15s %-30s\n","No","Name","Phone","Email");
            printf("-----------------------------------------------------\n");

             for(int i=0;i<addressBook->contactCount;i++)
            {
                if(strcmp(addressBook->contacts[i].email,search)==0)
                {
                    printf("%-5d %-20s %-15s %-30s",i+1,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
                    found=1;
                } 
            }
            if(!found)
            {
                printf("No contacts found searching by this email:%s\n",search);
            }
                return;

            case 4:
            printf("\n");
            break;
            default:
            printf("Invalid choice.please try again.\n");
        }
    } while (choice!=4);
}
                    
 void editContact(AddressBook *addressBook)
{
	if(addressBook->contactCount==0)
    {
        printf("No contacts to edit");
    }
    char search[50];
    int choice;
    int found=0;
    do
    {
        printf("\nEdit By:\n");
        printf("1.Name\n");
        printf("2.Phone number\n");
        printf("3.Email Id\n");
        printf("4.Back to main menu.\n");
            
        printf("Enter the choice:");
        scanf("%d",&choice);
        switch(choice)
        {
            case 1:
            printf("Enter name to Edit:");
            scanf(" %[^\n]",search);
            found=0;
            int attempts=0,maxAttempts=3;

            for(int i=0;i<addressBook->contactCount;i++)
            {
                if(strcmp(addressBook->contacts[i].name,search)==0)
                {
                    int j;
                    found=1;
                    printf("\nContact found\n");
                    printf("%-5s %-20s %-15s %-30s\n","No","Name","Phone","Email");
                    printf("----------------------------------------------------------\n");
                    printf("%-5d %-20s %-15s %-30s\n",i+1,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
                    
                    while(attempts<maxAttempts)
                    {
                        int valid=1,len;
                        attempts++;
                        printf("Enter new name(Attempt %d of %d):",attempts,maxAttempts);
                        scanf(" %[^\n]",addressBook->contacts[i].name);
                        len=strlen(addressBook->contacts[i].name);
                         if(len<3)
                        {
                            printf("Invalid: Name must be at least 3 characters long.\n");
                            valid=0;
                        }
                         else if(!isupper(addressBook->contacts[i].name[0]))
                        {
                            printf("Invalid: First letter must be uppercase.\n");
                            valid=0;
                        }
                        else
                        {
                            for(j=0;j<len;j++)
                            {
                                if(!isalpha(addressBook->contacts[i].name[j])&&addressBook->contacts[i].name[j]!=' ')
                                {
                                    printf("Invalid: Only alphabets and spaces are allowed.\n");
                                    valid=0;
                                    break;
                                }
                                if(addressBook->contacts[i].name[j] == ' '&&addressBook->contacts[i].name[j + 1] == ' ')
                                {
                                    printf("Invalid: Multiple spaces are not allowed.\n");
                                    valid=0;
                                    break;
                                }
                            }
                        }
                        if(valid)
                        {
                            printf("Valid name entered: %s\n", addressBook->contacts[i].name);
                            printf("Contact updated successfully.\n");
                            break;
                        }

                        if(attempts==maxAttempts)
                        {
                            printf("Too many invalid attempts. Name not updated.\n");
                        }
                    }
                    break;
                }
            }
            if (!found)
            {
                printf("No contact found with name:%s\n",search);
            }
            return;
    
            case 2:
            printf("Enter number to edit:");
            scanf(" %[^\n]",search);
            found=0;

            for(int i=0;i<addressBook->contactCount;i++) 
            {
            if(strcmp(addressBook->contacts[i].phone,search)==0)
            {
                found=1;
                printf("\nContact found:\n");
                printf("%-5s %-20s %-15s %-30s\n","No.","Name","Phone","Email");
                printf("---------------------------------------------------------------\n");
                printf("%-5d %-20s %-15s %-30s\n",i+1,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);

                int k; 
                attempts=0;maxAttempts=3;

                while(attempts<maxAttempts)
                {
                   int duplicate=0;
                   attempts++;
                   printf("Enter the Phone Number (Attempt %d of %d):",attempts,maxAttempts);
                   scanf(" %19[^\n]",addressBook->contacts[i].phone);

                   if(strlen(addressBook->contacts[i].phone)!=10) 
                   {
                        printf("Phone Number must be exactly 10 digits!\n");
                        continue;
                    }

                    for(k=0;k<10;k++) 
                    {
                        if(!isdigit(addressBook->contacts[i].phone[k])) 
                        {
                            printf("Phone Number must contain only digits!\n");
                            break;
                        }
                    }
                    if(k!=10)continue;

                    for(k=0;k<addressBook->contactCount;k++) 
                    {
                        if(k==i)continue;
                        if (strcmp(addressBook->contacts[k].phone,addressBook->contacts[i].phone)==0) 
                        {
                            printf("This phone number already exists!\n");
                            duplicate=1;
                            break;
                        }
                    }
                    if(duplicate)continue;

                    printf("Phone Number accepted: %s\n",addressBook->contacts[i].phone);
                    printf("Contact updated successfully.\n");
                    break;
                }
                if(attempts==maxAttempts)
                {
                    printf("Maximum attempts reached. Could not enter a valid phone number.\n");
                    return;
                }
            }
            if (!found)
            {
                printf("No contact found with number: %s\n", search);
            }
            return;
            }

           //edit by Email
            case 3:
            printf("Enter email to edit: ");
            scanf(" %[^\n]", search);
            found=0;
      
            for(int i=0;i<addressBook->contactCount;i++)
            {
                if(strcmp(addressBook->contacts[i].email,search)==0)
                {
                    found=1;
                    printf("\nContact found:\n");
                    printf("%-5s %-20s %-15s %-30s\n", "No.", "Name", "Phone", "Email");
                    printf("---------------------------------------------------------------\n");
                    printf("%-5d %-20s %-15s %-30s\n",i+1,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);

                   char email[50];
                   int attempts=0,maxAttempts=3;
                   while(attempts<maxAttempts)
                   {
                        int valid=1,Count=0;
                        attempts++;
                        printf("Enter the new Email (Attempt %d of %d):",attempts,maxAttempts);
                        scanf(" %[^\n]",email);

                        if(strcmp(search,email)==0)
                        {
                            printf("This email is the same as the old one. Please enter a different email.\n");
                            continue;
                        }

                        for(int j=0;email[j]!='\0';j++)
                        {
                            if(isupper(email[j]))
                            {
                                printf("Error: Email must be lowercase only.\n");
                                valid=0;
                                break;
                            }
                        }
                        if(!valid)continue;

                        for(int j=0;email[j]!='\0';j++)
                        {
                            if(email[j]=='@')Count++;
                        }
                        if(Count!=1)
                        {
                            printf("Error: Email must contain exactly one '@'.\n");
                            continue;
                        }

                        int len=strlen(email);
                        if(len<5||strcmp(&email[len-4],".com")!=0)
                        {
                            printf("Error: Email must end with '.com'.\n");
                            continue;
                        }

                        for(int j=0;email[j]!='\0';j++)
                        {
                            if(!(islower(email[j])||isdigit(email[j])||email[j]=='@'||email[j]=='.'||email[j]=='_'||email[j]=='-'))
                            {
                                printf("Error: Invalid character '%c'. Allowed: letters, digits, @ . _ -\n",email[j]);
                                valid=0;
                                break;
                            }
                        }
                        if(!valid)continue;

                        int duplicate=0;
                        for(int k=0;k<addressBook->contactCount;k++)
                        {
                           if(k==i) continue;
                           if(strcmp(addressBook->contacts[k].email,email)==0)
                           {
                                printf("This email already exists! Please enter a different email.\n");
                                duplicate=1;
                                 break;
                            }
                        }
                        if(duplicate)continue;
                        strcpy(addressBook->contacts[i].email, email);
                        printf("Contact updated successfully.\n");
                        break;
                    }

                    if(attempts==maxAttempts)
                   {
                        printf("Maximum attempts reached. Could not update email.\n");
                   }
                   break;
                }
            }

            if(!found)
            {
                printf("No contact found with Email: %s\n",search);
            }
            return;


          case 4:printf("\n");break;
          default:printf("Invalid choice. Please try again.\n");

        }
    }while(choice!=4);
}
                            
                    

void deleteContact(AddressBook *addressBook)
{
	if(addressBook->contactCount==0)
    {
        printf("\nNo contacts delete.");
        return;
    }
    while(1)
    {
        printf("\nDelete by:\n");
        printf("1.Name\n");
        printf("2.Phone\n");
        printf("3.Email\n");
        int choice,i,j,found=0;
        char search[50];
        printf("Enter choice:");
        scanf("%d",&choice);
        
        switch(choice)
        {
            case 1:
            printf("Enter name to delete:");
            scanf(" %[^\n]",search);

            for(i=0;i<addressBook->contactCount;i++)
            {
                if(strcmp(addressBook->contacts[i].name,search)==0)
                {
                    for(j=i;j<addressBook->contactCount-1;j++)
                    {
                        addressBook->contacts[j]=addressBook->contacts[j+1];
                    }
                    addressBook->contactCount--;
                    found=1;
                    printf("\nContact deleted successfully by Name.\n");
                    return;
                }
            }
            break;

            case 2:
            printf("Enter phone number to delete:");
            scanf(" %[^\n]",search);
            for(i=0;i<addressBook->contactCount;i++)
            {
                if(strcmp(addressBook->contacts[i].phone,search)==0)
                {
                    for(j=i;j<addressBook->contactCount-1;j++)
                    {
                        addressBook->contacts[j]=addressBook->contacts[j+1];
                    }
                    addressBook->contactCount--;
                    found=1;
                    printf("\nContact deleted successfully by phone.\n");
                    return;
                }
            }
            break;

            case 3:
            printf("Enter email to delete:");
            scanf(" %[^\n]",search);
            for(i=0;i<addressBook->contactCount;i++)
            {
                if(strcmp(addressBook->contacts[i].email,search)==0)
                {
                    for(j=i;j<addressBook->contactCount-1;j++)
                    {
                        addressBook->contacts[j]=addressBook->contacts[j+1];
                    }
                    addressBook->contactCount--;
                    found=1;
                    printf("\nContact deleted successfully by email.\n");
                    return;
                }
            }
            break;

            case 4:
            printf("\n");
            return;
            default:
            printf("\nInvalid choice.\n");
            return;
        }
        if(!found)
        {
            printf("\nNo matching contacts found.\n");
            break;
        }
    }
    return;
   
}
